import AIAssistantWithLearningUI from "@/components/ai-assistant-with-learning"

export default function AILearningPage() {
  return <AIAssistantWithLearningUI />
}


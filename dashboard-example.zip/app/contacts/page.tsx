import ContactsPage from "@/components/contacts-page"

export default function Contacts() {
  return <ContactsPage />
}


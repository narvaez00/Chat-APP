import LoginForm from "@/components/login-form"

export default function Home() {
  // In a real app, you would check if the user is logged in
  // For demo purposes, we'll just show the login page
  return <LoginForm />
}


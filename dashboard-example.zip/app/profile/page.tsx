import ProfileSettings from "@/components/profile-settings"

export default function ProfilePage() {
  return <ProfileSettings />
}


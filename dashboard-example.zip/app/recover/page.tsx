import RecoverForm from "@/components/recover-form"

export default function RecoverPage() {
  return <RecoverForm />
}


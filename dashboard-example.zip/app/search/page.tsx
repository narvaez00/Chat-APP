import SearchPage from "@/components/search-page"

export default function Search() {
  return <SearchPage />
}


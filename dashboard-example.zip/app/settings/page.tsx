import LanguageSettings from "@/components/language-settings"

export default function SettingsPage() {
  return <LanguageSettings />
}


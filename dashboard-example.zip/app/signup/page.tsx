import SignUpForm from "@/components/signup-form"

export default function SignUpPage() {
  return <SignUpForm />
}

